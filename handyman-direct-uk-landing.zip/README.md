# Handyman.direct — UK-first Landing (Vercel-ready)
Minimal, Apple-esque landing page with two entry points (Find talent / Find work), UK-first messaging, verified pros, and AI quote builder.

## Deploy on Vercel
1. Go to Vercel → New Project → Import → Upload.
2. Upload this folder (or the ZIP).
3. After deploy, go to Project → Settings → Domains and add your domain (handyman.direct).
4. If prompted for DNS:
   - A record for root (@) → 76.76.21.21
   - CNAME for www → cname.vercel-dns.com
5. HTTPS will auto-provision.
